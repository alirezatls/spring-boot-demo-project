package com.demo.web.webdemothymeleafmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebDemoThymeleafMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebDemoThymeleafMailApplication.class, args);
	}

}

